﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PracticeOOPs
{
    /*Inheritance, Polymorphism, Encapsulation*/
    public class Vehicle
    {
        public string Model { get; set; }
        public string Color { get; set; }
        public int Maxspeed { get; set; }
        public int Year { get; set; }
        protected int num;
        public void BreakControl()
        {
            Console.WriteLine("BreakControl function is Amazing..!");
        }
        public virtual double calSpped()
        {
            return (Maxspeed * Year);
        }

        public Vehicle(string model, string color, int maxspeed, int year) //parameterized constructor
        {
            this.Model = model;
            this.Color = color;
            this.Maxspeed = maxspeed;
            this.Year = year;
        }
        static Vehicle()
        {

        }
        Vehicle()//Default constructor initializes int to 0 and string to null
        {

        }
        private Vehicle(Vehicle v)//copy constructor
        {
            Color = v.Color;
            Year = v.Year;
        }
        
    }
    public class Bus : Vehicle
    {
        public string ModelType;
        public Bus(string model, string color, int maxspeed, int year):base(model,color, maxspeed, year)
        {
            ModelType = "Truck";
            //Console.WriteLine("Bus constructor");
        }
        public override double calSpped()
        {
            return (5*Maxspeed * Year);
        }
        public void BusDerived(string name)
        {
            Console.WriteLine("BusDerived: ", name);
        }

    }

    public class ChildBus : Bus
    {
        int child1 { get; set; }
        public ChildBus(string model, string color, int maxspeed, int year): base(model, color, maxspeed, year)
        {

        }
    }
    //
    //public class Human
    //{
    //    private string name;
    //    private int age;
    //    public string SayName()
    //    {
    //        get
    //        { 
    //            return name; 
    //        }

    //        set{ name = value; }

    //    }
    //}
    //public class Person : Human
    //{
    //    private void SayAge()
    //    {
    //        Console.WriteLine(age);
    //    }
    //}

    //


    /*Abstract class and methods*/
    abstract class Animal
    {
        public string Animalname { get; set; }
        public abstract void animalSound();
        public virtual void Sleep()
        {
            Console.WriteLine("The animal sleeps.");
        }
    }
    class Dog : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Dog says bow bow.");
        }
        //Dog(string animalName)
        //{
        //    Animalname = animalName;
        //}
    }
    class Cat: Animal
    {        
        public override void animalSound()
        {
            Console.WriteLine("Cat says meow meow.");
        }
    }
    /*Interface*/
    interface IExercise
    {
        void running();//interface methods
        void pushups();
    }
    class Cardio : IExercise
    {
        public void running()
        {
            Console.WriteLine("Cardio-running");
        }
        public void pushups()
        {
            Console.WriteLine("Cardio-pushups");
        }
    }
    /*Enums*/
    enum Days
    {
        Sun, Mon, Tues, Wed, Thurs, Fri, Sat
    }
    static class Provestatic
    {
        public static int val_static;
        //public int val_noStatic;
        public static string Value { get; set; }
        public static void Add_static() { Console.WriteLine("Static method"); }
        //public void Add_noStatic() { Console.WriteLine("noStatic method"); }
        public static string GetNextName(out int id)
        {
            id = 1;
            string returnText = "Next-" + id.ToString();
            return returnText;
        }
    }
    /*more practice on OOPs*/
    //Indexer class
    class IndexerData
    {
        private string[] strArr = new string[10];
        public string this[int index]
        {
            get 
            {
                if (index < 0 || index > strArr.Length)
                {
                    throw new IndexOutOfRangeException("Index out of range");
                }
                return strArr[index];
            }
            set 
            {
                if (index<0 || index >strArr.Length)
                {
                    throw new IndexOutOfRangeException("Index out of range");
                }
                strArr[index] = value;
            }
        }
    }

    //Generics
    public class DataStore<T,U>
    {
        public T Data { get; set; }
        public U Num { get; set; }

        public T[] aar = new T[10];
        public void print(T Data)
        {
            Console.WriteLine(Data);
        }
        public DataStore(T data, U num)
        {
            this.Data = data;
            this.Num = num;
        }
    }
    public class Student 
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    //------------------------------------------------------------------
    //Factory Method OOP design implementation for ToasterFactory example

    abstract class Toaster  //Product class
    {
        public abstract string ToasterType { get; }
        public abstract string TypeOfSlot { get; set; }
        public abstract int NoOfSlots { get; set; }
    }
    //Concrete products
    class TwoSlotWideToaster : Toaster 
    {
        private readonly string _toasterType;
        private string _typeOfSLot;
        private int _noOfSlots;

        public TwoSlotWideToaster(string typeOfSlot, int noOfSlots)
        {
            _toasterType = "TwoSlotWide";
            _typeOfSLot = typeOfSlot;
            _noOfSlots = noOfSlots;
        }
        public override string ToasterType
        {
            get { return _toasterType; }
        }
        public override string TypeOfSlot
        {
            get { return _typeOfSLot; }
            set { _typeOfSLot = value; }
        }
        public override int NoOfSlots
        {
            get { return _noOfSlots; }
            set { _noOfSlots = value; }
        }
    }
    class TwoSlotRegularToaster : Toaster
    {
        private readonly string _toasterType;
        private string _typeOfSLot;
        private int _noOfSlots;

        public TwoSlotRegularToaster(string typeOfSlot, int noOfSlots)
        {
            _toasterType = "TwoSlotRegular";
            _typeOfSLot = typeOfSlot;
            _noOfSlots = noOfSlots;
        }
        public override string ToasterType
        {
            get { return _toasterType; }
        }
        public override string TypeOfSlot
        {
            get { return _typeOfSLot; }
            set { _typeOfSLot = value; }
        }
        public override int NoOfSlots
        {
            get { return _noOfSlots; }
            set { _noOfSlots = value; }
        }
    }
    class FourSlotWideToaster : Toaster
    {
        private readonly string _toasterType;
        private string _typeOfSLot;
        private int _noOfSlots;

        public FourSlotWideToaster(string typeOfSlot, int noOfSlots)
        {
            _toasterType = "FourSlotWide";
            _typeOfSLot = typeOfSlot;
            _noOfSlots = noOfSlots;
        }
        public override string ToasterType
        {
            get { return _toasterType; }
        }
        public override string TypeOfSlot
        {
            get { return _typeOfSLot; }
            set { _typeOfSLot = value; }
        }
        public override int NoOfSlots
        {
            get { return _noOfSlots; }
            set { _noOfSlots = value; }
        }
    }
    class FourSlotRegularToaster : Toaster
    {
        private readonly string _toasterType;
        private string _typeOfSLot;
        private int _noOfSlots;

        public FourSlotRegularToaster(string typeOfSlot, int noOfSlots)
        {
            _toasterType = "FourSlotRegular";
            _typeOfSLot = typeOfSlot;
            _noOfSlots = noOfSlots;
        }
        public override string ToasterType
        {
            get { return _toasterType; }
        }
        public override string TypeOfSlot
        {
            get { return _typeOfSLot; }
            set { _typeOfSLot = value; }
        }
        public override int NoOfSlots
        {
            get { return _noOfSlots; }
            set { _noOfSlots = value; }
        }
    }
    //Creater
    abstract class ToasterFactory
    {
        public abstract Toaster GetToaster();
    }
    //Concrete creator
    class TwoSlotWideToasterFactory : ToasterFactory
    {
        private string _typeOfSLot;
        private int _noOfSlots;
        public TwoSlotWideToasterFactory(string typeOfSlot, int noOfSlots)
        {
            _typeOfSLot = typeOfSlot;
            _noOfSlots = noOfSlots;
        }
        public override Toaster GetToaster()
        {
            return new TwoSlotWideToaster(_typeOfSLot, _noOfSlots);
        }
    }
    class TwoSlotRegularToasterFactory : ToasterFactory
    {
        private string _typeOfSLot;
        private int _noOfSlots;
        public TwoSlotRegularToasterFactory(string typeOfSlot, int noOfSlots)
        {
            _typeOfSLot = typeOfSlot;
            _noOfSlots = noOfSlots;
        }
        public override Toaster GetToaster()
        {
            return new TwoSlotRegularToaster(_typeOfSLot, _noOfSlots);
        }
    }
    class FourSlotWideToasterFactory : ToasterFactory
    {
        private string _typeOfSLot;
        private int _noOfSlots;
        public FourSlotWideToasterFactory(string typeOfSlot, int noOfSlots)
        {
            _typeOfSLot = typeOfSlot;
            _noOfSlots = noOfSlots;
        }
        public override Toaster GetToaster()
        {
            return new FourSlotWideToaster(_typeOfSLot, _noOfSlots);
        }
    }
    class FourSlotRegularToasterFactory : ToasterFactory
    {
        private string _typeOfSLot;
        private int _noOfSlots;
        public FourSlotRegularToasterFactory(string typeOfSlot, int noOfSlots)
        {
            _typeOfSLot = typeOfSlot;
            _noOfSlots = noOfSlots;
        }
        public override Toaster GetToaster()
        {
            return new FourSlotRegularToaster(_typeOfSLot, _noOfSlots);
        }
    }
}
