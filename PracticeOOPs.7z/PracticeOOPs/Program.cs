﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Linq;

namespace PracticeOOPs
{

    class Program
    {
        //-Number to words converter--
        static String PrintEnglishWords(double num)
        {
            string OutputWord = "";
            double intPotion;
            double nonIntPortion = 0;
            if (num == 0)
                return OutputWord = "zero";
            try
            {
                //this portion seperates the input number into whole int portion and nonint portion
                string[] seperator = num.ToString().Split('.');
                intPotion = double.Parse(seperator[0]);
                nonIntPortion = double.Parse(seperator[1]);
            }
            catch
            {
                intPotion = num;
            }
            //this NumberToWords method for intportion of input number uses recursive technique and Math.pow and Math.Floor methods 
            OutputWord = NumberToWords(intPotion);

            //this portion of if handles nonint portion of number, upto ten-thousandths place
            if (nonIntPortion > 0)
            {
                int count = nonIntPortion.ToString().Length;
                //Upto four decimal points will be converted  
                if (OutputWord != "" && count <= 4)
                    OutputWord += " and ";
                if (count <= 4)
                {
                    switch (count)
                    {
                        case 1: OutputWord += NumberToWords(nonIntPortion) + " tenths"; break;
                        case 2: OutputWord += NumberToWords(nonIntPortion) + " hundredths"; break;
                        case 3: OutputWord += NumberToWords(nonIntPortion) + " thousandths"; break;
                        case 4: OutputWord += NumberToWords(nonIntPortion) + " ten-thousandths"; break;
                    }
                }
            }
            return OutputWord;
        }

        static String NumberToWords(double num) //converts double intportion to words
        {
            string[] initialNumbersArray = new string[] { "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
            string[] tensArray = new string[] { "twenty", "thirty", "fourty", "fifty", "sixty", "seventy", "eighty", "ninty" };
            string[] HigherSuffixesArray = new string[] { "thousand", "million", "billion", "trillion", "quadrillion", "quintillion" };
            string OutputWord = "";

            bool tens = false;

            if (num < 0)
            {
                OutputWord += "negative ";
                num *= -1;
            }

            int power = (HigherSuffixesArray.Length + 1) * 3;

            while (power > 3)
            {
                double pow = Math.Pow(10, power);
                if (num >= pow)
                {
                    if (num % pow > 0)
                    {
                        OutputWord += NumberToWords(Math.Floor(num / pow)) + " " + HigherSuffixesArray[(power / 3) - 1] + ", ";
                    }
                    else if (num % pow == 0)
                    {
                        OutputWord += NumberToWords(Math.Floor(num / pow)) + " " + HigherSuffixesArray[(power / 3) - 1];
                    }
                    num %= pow;
                }
                power -= 3;
            }
            if (num >= 1000)
            {
                if (num % 1000 > 0) OutputWord += NumberToWords(Math.Floor(num / 1000)) + " thousand, ";
                else OutputWord += NumberToWords(Math.Floor(num / 1000)) + " thousand";
                num %= 1000;
            }
            if (0 <= num && num <= 999)
            {
                if ((int)num / 100 > 0)
                {
                    OutputWord += NumberToWords(Math.Floor(num / 100)) + " hundred";
                    num %= 100;
                }
                if ((int)num / 10 > 1)
                {
                    if (OutputWord != "")
                        OutputWord += " ";
                    OutputWord += tensArray[(int)num / 10 - 2];
                    tens = true;
                    num %= 10;
                }

                if (num < 20 && num > 0)
                {
                    if (OutputWord != "" && tens == false)
                        OutputWord += " ";
                    OutputWord += (tens ? "-" + initialNumbersArray[(int)num - 1] : initialNumbersArray[(int)num - 1]);
                    num -= Math.Floor(num);
                }
            }
            return OutputWord;
        }

        static int[] TwoSum(int[] nums, int target)
        {

            int[] result = new int[] { -1, -1 };
            if (nums == null)
                return result;
            if (nums.Length < 2)
                return result;

            Dictionary<int, int> map = new Dictionary<int, int>();

            for (int i = 0; i < nums.Length; i++)
            {
                int diff = target - nums[i];
                if (map.ContainsKey(diff))
                {
                    result[0] = map[diff];
                    result[1] = i;
                    //Console.WriteLine(result[0].ToString());
                    //Console.WriteLine(result[1].ToString());
                    return result;
                }

                //if duplicate number is present
                if (map.ContainsKey(nums[i]))
                    continue;
                map.Add(nums[i], i);

            }
            //Console.WriteLine(result);
            return result;
        }
        static void Main(string[] args)
        {
            ////Indexer
            //IndexerData obj = new IndexerData();
            //obj[0] = "one";
            //obj[1] = "two";
            //Console.WriteLine(obj[1]);
            ////Generics
            //DataStore<string, int> obj1 = new DataStore<string, int>("obj1",1000);
            //DataStore<int,int> obj2 = new DataStore<int, int>(10,20);
            ////obj1.Data = "Generics";
            ////obj1.Num = 1000;
            ////obj1.print("500");
            //obj1.aar[0] = "elm1";
            //Console.WriteLine(obj1.aar[0]);


            //Colletions - ArrayList, List, SortedList, Dictionary, Hashtable, Stack, Queue
            //ArrayList arrlist = new ArrayList();
            //var arlist = new ArrayList();
            //var arlist2 = new ArrayList() {1,2,3,4, "Arlist" };
            //int[] arr = new int[] { 11, 22, 33, 44 };
            //Queue myQ = new Queue();
            //myQ.Enqueue("Hello");
            //myQ.Enqueue("Queue");

            //arlist.Add(777);
            //arlist.AddRange(arlist2);
            //arlist.AddRange(arr);
            //arlist.AddRange(myQ);
            //arlist.Add(obj1.aar);
            //Console.WriteLine(arlist.Count);
            //foreach (var item in arlist)
            //{
            //    Console.Write(item+", ");
            //}

            //Console.WriteLine("\n\nList");
            ////list
            //List<int> oddNum = new List<int>() {1,3,5,7 };
            //oddNum.Add(9);
            //oddNum.AddRange(arr);
            //Console.WriteLine(oddNum.Count);
            //oddNum.ForEach(num => Console.Write(num+", "));
            //Console.WriteLine("\n\nAccess List using LINQ");
            ////access List using LINQ
            //var students = new List<Student>() { new Student() { Id = 1, Name = "AAA" }, new Student() { Id = 2, Name = "BBB" }, new Student() { Id = 3, Name = "CCC" } };
            //var result = from s in students
            //             where s.Name == "AAA"
            //             select s;

            //foreach (var item in result)
            //{
            //    Console.WriteLine(item.Id+ ", "+item.Name);
            //}


            //int[] nums = new int[] { 2, 7, 11, 15 };
            //int target = 923;
            //int[] result = TwoSum(nums,target);

            //bool negativeflag = false;
            //int x = -123;
            //if (x < 0 && negativeflag == false)
            //{
            //    negativeflag = true;
            //    x = -x;
            //}

            //int rev = 0;
            //while (x > 0)
            //{
            //    rev = rev * 10 + x % 10;
            //    x /= 10;
            //}

            //if (negativeflag == true)
            //{
            //    rev = -rev;
            //}
            //Console.WriteLine(rev);

            //foreach (var item in result)
            //{
            //    Console.Write(result[item]);
            //}

            Console.Write("Please enter a number(+ or -) to convert into words format: ");
            Double number = Double.Parse(Console.ReadLine());
            Console.WriteLine("{0}", PrintEnglishWords(number));

            //reverse the order of the words given in a string
            //int i = 0;
            //string rev = "Welcome to CSharp corner";
            //StringBuilder revSentence = new StringBuilder();
            //int Start = rev.Length - 1;
            //int End = rev.Length - 1;
            //while (Start > 0)
            //{
            //    if (rev[Start] == ' ')
            //    {
            //        i = Start + 1;
            //        while (i <= End)
            //        {
            //            revSentence.Append(rev[i]);
            //            i++;
            //        }
            //    }
            //}

            ////Palindrome or not
            //string strP = "maddam";
            //bool flag = false;
            //Console.WriteLine(strP.Length / 2);
            //for (int i = 0, j = strP.Length - 1; i < strP.Length / 2; i++, j--)
            //{
            //    if (strP[i] != strP[j])
            //    {
            //        flag = false;
            //        break;
            //    }
            //    else
            //    {
            //        flag = true;
            //    }
            //}

            //if (flag == true)
            //{ Console.WriteLine("Palindrome"); }
            //else
            //{ Console.WriteLine("Not Palindrome"); }


            ////Reverse string
            //string str = "ABCDEF";
            //Console.WriteLine(str);
            //char[] CharArray = str.ToCharArray();
            //Console.WriteLine(CharArray);

            //for (int i = 0, j = str.Length - 1; i < j; i++, j--)
            //{
            //    CharArray[i] = str[j];
            //    CharArray[j] = str[i];
            //}
            //string reveresedString = new string(CharArray);
            //Console.WriteLine(reveresedString);
            //-----------------------------------------------------------------------------------------------------------------------

            /*Inheritance, Polymorphism, Encapsulation*/
            //Console.WriteLine("------------Inheritance, Polymorphism, Encapsulation----------");
            //Vehicle Car = new Vehicle("Munja1", "Brown1", 5001, 20211);
            ////Vehicle Truck = new Vehicle();
            //Car.Model = "Ford-Mustang";
            //Console.WriteLine(Car.Model);
            //double Baseout = Car.calSpped();
            ////Console.WriteLine("Model:"+Car.Model+"\n"+"Color: "+Car.Color+"\n"+"Maxspeed: "+Car.Maxspeed+"\n"+"Year: "+Car.Year);

            //Bus b = new Bus("Munja", "Brown", 500, 2021);
            //double Derout = b.calSpped();
            //Console.WriteLine(Baseout + "\t" + Derout);
            ////b.BreakControl();
            //Console.WriteLine(b.Model + "\t" + b.ModelType);
            ////Vehicle vehicle = new Vehicle("Munja1", "Brown1", 5001, 20211);

            //factory Method 
            // TwoSlotWide, TwoSlotRegular, FourSlotWide, FourSlotRegular
            ToasterFactory factory = null;
            Console.WriteLine("Enter the Toaster type you want to visit: ");
            string machine = Console.ReadLine();
            
            switch (machine.ToLower())
            {
                
                case "twostlotwide":
                    factory = new TwoSlotWideToasterFactory("Wide",2);
                    Console.WriteLine(machine + "inside switch");
                    break;
                case "twoslotregular":
                    factory = new TwoSlotRegularToasterFactory("Regular", 2);
                    Console.WriteLine(machine + "inside switch");
                    break;
                case "fourslotwide":
                    factory = new FourSlotWideToasterFactory("Wide", 4);
                    Console.WriteLine(machine + "inside switch");
                    break;
                case "fourslotregular":
                    factory = new FourSlotRegularToasterFactory("Regular", 4);
                    Console.WriteLine(machine + "inside switch");
                    break;
                default:
                    //here we can implement the non-satisfying condition
                    break;
            }
            Console.WriteLine(machine);

            Toaster toaster = factory.GetToaster();
            Console.WriteLine("\nYour Toaster details are below: \n");
            Console.WriteLine("Toaster Type: {0}\nType of Slot: {1}\nNo of Slots: {2}",toaster.ToasterType, toaster.TypeOfSlot, toaster.NoOfSlots);
            Console.ReadKey();




            ///*Abstract class and methods*/
            //Console.WriteLine("--------------------Abstract class and methods-----------------");
            ////Animal animal = new Animal();
            //Animal mydog = new Dog();
            //Animal myCat = new Cat();
            ////animal.animalSound();
            //myCat.animalSound(); //abstract method
            //mydog.animalSound(); //abstract method
            //mydog.Sleep();//regular method
            //Console.WriteLine(mydog.Animalname);

            ///*Interface*/
            //Console.WriteLine("-------------------Interface----------------------");
            //Cardio myCardio = new Cardio();
            //myCardio.running();
            //myCardio.pushups();

            ///*Enums*/
            //Console.WriteLine("--------------Enums--------------------");

            //int myDay = (int)Days.Fri;
            //Console.WriteLine(myDay);

            ///*Static class with static field, static method and static property*/
            //Console.WriteLine("--------------Static class with static field, static method and static property--------------------");
            ////Provestatic p = new Provestatic(); //cannot create instance of static class
            ////p.Add_noStatic();
            ////p.val_noStatic = 10;
            //Provestatic.Add_static();
            //Provestatic.val_static = 10;
            //Provestatic.Value = "Static string property in static class";
            //Console.WriteLine(Provestatic.val_static + "---" + Provestatic.Value);

            //int i = 10;
            //Console.WriteLine("Previous value of int i: "+i.ToString());
            //string test = Provestatic.GetNextName(out i);
            //Console.WriteLine("Current value of int i: " + i.ToString());

            //Console.WriteLine("--------------End of Program--------------------");
            ////-----Algorithm practice-------------------------------------------------------------
            //string[] input = "i love programming very much".Split(' ');
            //Console.WriteLine(input);
            //string ans = "";
            //for (int j = input.Length - 1; j >=0; j--)
            //{
            //    ans += input[j] + " ";
            //    Console.WriteLine(ans);
            //}
            //Console.Write("Reversed string:");
            //Console.Write(ans.Substring(0,ans.Length-1));

            ////Console.WriteLine("Enter string");
            //string input2 = Console.ReadLine();
            //Console.WriteLine(input2);
            //int LenInp2 = input2.Length;
            //string[] Arr1 = new string[input2.Length];



        }
    }
}



